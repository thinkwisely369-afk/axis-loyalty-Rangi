<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Otp;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    /**
     * Send OTP to mobile number
     */
    public function sendOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'mobile_number' => 'required|string|min:10|max:15',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $mobileNumber = $request->mobile_number;

        // Generate OTP
        $otp = Otp::generate($mobileNumber);

        // TODO: Integrate with SMS gateway to send OTP
        // For development, we'll return the OTP (REMOVE IN PRODUCTION)
        $isDevelopment = config('app.env') === 'local';

        return response()->json([
            'success' => true,
            'message' => 'OTP sent successfully',
            'otp' => $isDevelopment ? $otp : null, // Only in development
        ]);
    }

    /**
     * Verify OTP and check user type
     */
    public function verifyOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'mobile_number' => 'required|string',
            'otp' => 'required|string|size:6',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $mobileNumber = $request->mobile_number;
        $otp = $request->otp;

        // Verify OTP
        if (!Otp::verify($mobileNumber, $otp)) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid or expired OTP'
            ], 401);
        }

        // Check if user exists (management or staff)
        $user = User::where('mobile_number', $mobileNumber)->first();

        if ($user && in_array($user->role, ['management', 'staff'])) {
            // Management or Staff - grant immediate access
            $token = $user->createToken('auth_token')->plainTextToken;

            return response()->json([
                'success' => true,
                'user_type' => $user->role,
                'requires_policy' => false,
                'user' => $user,
                'token' => $token,
            ]);
        }

        // New user or customer - requires policy verification
        return response()->json([
            'success' => true,
            'user_type' => 'customer',
            'requires_policy' => true,
            'mobile_number' => $mobileNumber,
        ]);
    }

    /**
     * Verify policy number with insurance company API
     */
    public function verifyPolicy(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'mobile_number' => 'required|string',
            'policy_number' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $mobileNumber = $request->mobile_number;
        $policyNumber = $request->policy_number;

        // Call insurance company API to verify policy
        $policyData = $this->checkPolicyWithInsuranceAPI($policyNumber);

        if (!$policyData || !$policyData['valid']) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid policy number or policy not found'
            ], 404);
        }

        // Create or update user with policy information
        $user = User::updateOrCreate(
            ['mobile_number' => $mobileNumber],
            [
                'name' => $policyData['customer_name'],
                'policy_number' => $policyNumber,
                'role' => 'customer',
                'is_verified' => true,
            ]
        );

        $token = $user->createToken('auth_token')->plainTextToken;

        return response()->json([
            'success' => true,
            'message' => 'Policy verified successfully',
            'user' => $user,
            'token' => $token,
        ]);
    }

    /**
     * Check policy with insurance company API
     * 
     * @param string $policyNumber
     * @return array|null
     */
    private function checkPolicyWithInsuranceAPI(string $policyNumber): ?array
    {
        try {
            // TODO: Replace with actual insurance company API endpoint
            $apiUrl = config('services.insurance.api_url');
            $apiKey = config('services.insurance.api_key');

            // For development/testing, return mock data
            if (config('app.env') === 'local') {
                // Mock response - replace with actual API call
                return [
                    'valid' => true,
                    'customer_name' => 'John Doe', // This should come from API
                    'policy_number' => $policyNumber,
                ];
            }

            // Actual API call (uncomment and configure when ready)
            /*
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $apiKey,
                'Accept' => 'application/json',
            ])->post($apiUrl . '/verify-policy', [
                'policy_number' => $policyNumber,
            ]);

            if ($response->successful()) {
                $data = $response->json();
                return [
                    'valid' => $data['valid'] ?? false,
                    'customer_name' => $data['customer_name'] ?? null,
                    'policy_number' => $policyNumber,
                ];
            }
            */

            return null;
        } catch (\Exception $e) {
            \Log::error('Insurance API Error: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Get authenticated user
     */
    public function me(Request $request)
    {
        return response()->json([
            'success' => true,
            'user' => $request->user(),
        ]);
    }

    /**
     * Logout user
     */
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'success' => true,
            'message' => 'Logged out successfully'
        ]);
    }
}
