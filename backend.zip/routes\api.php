<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;

// All API routes require API token validation
Route::middleware('validate.api.token')->group(function () {

    // Public routes (no user authentication required, but API token required)
    Route::post('/auth/send-otp', [AuthController::class, 'sendOtp']);
    Route::post('/auth/verify-otp', [AuthController::class, 'verifyOtp']);
    Route::post('/auth/verify-policy', [AuthController::class, 'verifyPolicy']);

    // Protected routes (require both API token AND user authentication)
    Route::middleware('auth:sanctum')->group(function () {
        Route::get('/auth/me', [AuthController::class, 'me']);
        Route::post('/auth/logout', [AuthController::class, 'logout']);

        // Add other protected routes here
    });

});
